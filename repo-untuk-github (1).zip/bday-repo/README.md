# 🎂 Happy Birthday — Scrapbook Edition

Website ucapan ulang tahun interaktif dengan tema scrapbook (cream & merah marun), countdown ke hari-H dalam WIB, musik live-coded via [Strudel](https://strudel.cc), dan fortune cookie yang bisa dipecahkan untuk quote positif.

## 🔗 Lihat langsung

Setelah di-deploy lewat GitHub Pages, buka:
`https://<username-kamu>.github.io/<nama-repo>/`

## ✏️ Cara mengedit isi

Semua yang perlu diganti ada di dalam `index.html`. Cari kata **`EDIT_ME`** untuk menemukan bagian konfigurasi, atau ubah langsung bagian berikut:

| Yang mau diganti | Cari di file |
|---|---|
| Tanggal & jam target ulang tahun (WIB) | variabel `TARGET_DATE_WIB` di bagian `<script>` |
| Quote di dalam fortune cookie | array `FORTUNE_QUOTES` |
| Foto polaroid | atribut `src` pada `<img id="polaroidImg">` — ganti dengan link foto kamu |
| Teks ucapan ulang tahun | isi `<div class="letter-body" id="letterBody">` |
| Nama penerima / sapaan | `<p class="letter-greeting">` dan `<p class="letter-signoff">` |

## 🎵 Tentang musik

Musik di halaman ini bukan file audio — dia digenerate langsung di browser saat halaman dibuka, menggunakan [Strudel](https://strudel.cc), sebuah live-coding environment untuk musik algoritmik berbasis JavaScript (porting dari TidalCycles).

Pattern lagu "Happy Birthday" pada situs ini dibuat oleh **[terryds](https://github.com/terryds)** di Strudel. Kredit penuh untuknya atas pattern-nya.

Karena musik ini di-generate lewat instrumen General MIDI yang di-load dari internet saat runtime, dibutuhkan koneksi internet aktif agar musik bisa diputar, dan akan ada sedikit delay loading di percobaan play pertama.

## 📜 Lisensi & atribusi

Situs ini menggunakan library [Strudel](https://strudel.cc) (`@strudel/web`), yang dilisensikan di bawah **AGPL-3.0**. Sesuai ketentuan lisensi tersebut:
- Source code situs ini (file `index.html`) disediakan terbuka di repository ini.
- Jika kamu memodifikasi dan mempublikasikan ulang situs ini, source code modifikasinya juga harus tetap tersedia secara terbuka di bawah lisensi yang sama atau kompatibel.

Lihat detail lisensi AGPL-3.0 di: https://www.gnu.org/licenses/agpl-3.0.en.html

## 🚀 Cara deploy ke GitHub Pages

1. Push isi folder ini ke repository GitHub kamu.
2. Masuk ke **Settings → Pages**.
3. Pada **Source**, pilih branch `main` dan folder `/ (root)`.
4. Tunggu beberapa menit, lalu situsmu aktif di `https://<username>.github.io/<repo>/`.
